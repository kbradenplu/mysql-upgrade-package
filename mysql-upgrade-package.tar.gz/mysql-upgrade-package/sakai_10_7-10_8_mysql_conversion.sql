-- SAK-29571 MFR_MESSAGE_DELETD_I causes bad performance                                                            
-- drop index MFR_MESSAGE_DELETED_I on MFR_MESSAGE_T;
-- END SAK-29571 MFR_MESSAGE_DELETD_I causes bad performance

-- LSNBLDR-500
alter table lesson_builder_pages add folder varchar(250);
create index lesson_builder_page_folder on lesson_builder_pages(siteId, folder);
-- sites new with 10 will already have this but it was missing in 10 conversion scripts
alter table lesson_builder_groups modify column groups longtext;
-- drop index lesson_builder_qr_questionId on  lesson_builder_q_responses ;
