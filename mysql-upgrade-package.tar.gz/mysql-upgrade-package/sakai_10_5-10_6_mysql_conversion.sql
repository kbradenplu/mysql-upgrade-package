-- SAK-29571 MFR_MESSAGE_DELETD_I causes bad performance
drop index MFR_MESSAGE_DELETED_I on MFR_MESSAGE_T;
-- END SAK-29571 MFR_MESSAGE_DELETD_I causes bad performance
