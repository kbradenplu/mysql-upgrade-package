#!/bin/bash

export DB=sakai12_schema_exp
export USER=kbraden
export TMPFILE=tmp.sql

# The scriptlist will be executed in order, so the order is important. 
scriptlist=(
'sakai_10_0_mysql_conversion.sql'
'sakai_10_0-10_1_mysql_conversion.sql'
'sakai_10_1-10_5_mysql_conversion.sql'
'sakai_10_5-10_6_mysql_conversion.sql'
'sakai_10_7-10_8_mysql_conversion.sql'
'sakai_11_mysql_conversion.sql'
'sakai_11_0-11_1_mysql_conversion.sql'
'sakai_11_1-11_2_mysql_conversion.sql'
'sakai_11_2-11_3_mysql_conversion.sql'
'sakai_11_3-11_4_mysql_conversion.sql'
'sakai_11_4-11_5_mysql_conversion.sql'
'sakai_12_mysql_conversion.sql'
)

CONCAT=''

count=0
while [ "x${scriptlist[count]}" != "x" ]
do
  export CONCAT="$CONCAT ${scriptlist[count]} "
  count=$(( count + 1))
done

cat $CONCAT > $TMPFILE

mysql -u $USER -p --force $DB < $TMPFILE
